-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: ginto
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_id` int DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_activity_logs_user` (`user_id`),
  KEY `idx_activity_logs_model` (`model_type`,`model_id`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,1,'test:provider_error','unified_mcp',0,'<script>alert(1)</script> Provider details: SECRET_TOKEN=abc123',NULL,NULL,'2025-12-06 10:50:09'),(2,1,'test:provider_error','unified_mcp',0,'<script>alert(1)</script> Provider details: SECRET_TOKEN=abc123',NULL,NULL,'2025-12-06 10:51:26'),(3,1,'test:provider_error','unified_mcp',0,'<script>alert(1)</script> Provider details: SECRET_TOKEN=abc123',NULL,NULL,'2025-12-06 10:51:53'),(5,2,'playground.save_exception','playground.editor',NULL,'[2025-12-06T10:58:04+00:00] playground/save exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table \'ginto.client_sandboxes\' doesn\'t exist in /home/oliverbob/ginto/vendor/catfan/medoo/src/Medoo.php:629',NULL,NULL,'2025-12-06 10:58:04'),(6,2,'playground.save_exception','playground.editor',NULL,'[2025-12-06T10:58:15+00:00] playground/save exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table \'ginto.client_sandboxes\' doesn\'t exist in /home/oliverbob/ginto/vendor/catfan/medoo/src/Medoo.php:629',NULL,NULL,'2025-12-06 10:58:15'),(7,2,'playground.save_exception','playground.editor',NULL,'[2025-12-06T10:58:27+00:00] playground/save exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table \'ginto.client_sandboxes\' doesn\'t exist in /home/oliverbob/ginto/vendor/catfan/medoo/src/Medoo.php:629',NULL,NULL,'2025-12-06 10:58:27'),(18,1,'playground.sample','playground.editor',0,'Sample log created from UI\n\nGenerated at: 2025-12-06T12:05:04+00:00',NULL,NULL,'2025-12-06 12:05:04'),(19,1,'playground.sample','playground.editor',0,'Sample log created from UI\n\nGenerated at: 2025-12-06T12:05:07+00:00',NULL,NULL,'2025-12-06 12:05:07'),(20,1,'llm_provider_error','llm',NULL,'{\"message\":\"json_decode(): Argument #1 ($json) must be of type string, false given\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::getProjectStructure\",\"tool\":\"get_project_structure\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:10:07'),(21,1,'llm_provider_error','llm',NULL,'{\"message\":\"Streaming error: Client error: `POST https://api.groq.com/openai/v1/chat/completions` resulted in a `400 Bad Request` response\",\"meta\":{\"user_message\":\"test\",\"provider\":\"groq\",\"streaming\":true}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:10:08'),(22,1,'internal_error','/chat',NULL,'{\"message\":\"Class \\\"App\\\\Core\\\\LLM\\\\Providers\\\\OpenAICompatibleProvider\\\" not found\",\"meta\":{\"route\":\"/chat\",\"trace\":\"#0 /home/oliverbob/ginto/src/Core/LLM/LLMProviderFactory.php(98): App\\\\Core\\\\LLM\\\\LLMProviderFactory::create()\\n#1 /home/oliverbob/ginto/src/Core/LLM/UnifiedMcpClient.php(43): App\\\\Core\\\\LLM\\\\LLMProviderFactory::fromEnv()\\n#2 /home/oliverbob/ginto/src/Routes/web.php(817): App\\\\Core\\\\LLM\\\\UnifiedMcpClient->__construct()\\n#3 [internal function]: {closure}()\\n#4 /home/oliverbob/ginto/src/Core/Router.php(150): call_user_func_array()\\n#5 /home/oliverbob/ginto/public/index.php(1139): Core\\\\Router->dispatch()\\n#6 {main}\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:20:10'),(23,1,'internal_error','/chat',NULL,'{\"message\":\"Class \\\"App\\\\Core\\\\LLM\\\\Providers\\\\OpenAICompatibleProvider\\\" not found\",\"meta\":{\"route\":\"/chat\",\"trace\":\"#0 /home/oliverbob/ginto/src/Core/LLM/LLMProviderFactory.php(98): App\\\\Core\\\\LLM\\\\LLMProviderFactory::create()\\n#1 /home/oliverbob/ginto/src/Core/LLM/UnifiedMcpClient.php(43): App\\\\Core\\\\LLM\\\\LLMProviderFactory::fromEnv()\\n#2 /home/oliverbob/ginto/src/Routes/web.php(817): App\\\\Core\\\\LLM\\\\UnifiedMcpClient->__construct()\\n#3 [internal function]: {closure}()\\n#4 /home/oliverbob/ginto/src/Core/Router.php(150): call_user_func_array()\\n#5 /home/oliverbob/ginto/public/index.php(1139): Core\\\\Router->dispatch()\\n#6 {main}\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:20:16'),(24,1,'llm_provider_error','llm',NULL,'{\"message\":\"json_decode(): Argument #1 ($json) must be of type string, false given\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::getProjectStructure\",\"tool\":\"get_project_structure\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:20:38'),(25,1,'llm_provider_error','llm',NULL,'{\"message\":\"Streaming error: Client error: `POST https://api.groq.com/openai/v1/chat/completions` resulted in a `400 Bad Request` response\",\"meta\":{\"user_message\":\"test\",\"provider\":\"groq\",\"streaming\":true}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:20:38'),(26,1,'llm_provider_error','llm',NULL,'{\"message\":\"json_decode(): Argument #1 ($json) must be of type string, false given\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::getProjectStructure\",\"tool\":\"get_project_structure\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:23:44'),(27,1,'llm_provider_error','llm',NULL,'{\"message\":\"Streaming error: Client error: `POST https://api.groq.com/openai/v1/chat/completions` resulted in a `400 Bad Request` response\",\"meta\":{\"user_message\":\"test\",\"provider\":\"groq\",\"streaming\":true}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:23:44'),(28,1,'internal_error','/chat',NULL,'{\"message\":\"No LLM provider configured. Set LLM_PROVIDER or configure an API key.\",\"meta\":{\"route\":\"/chat\",\"trace\":\"#0 /home/oliverbob/ginto/src/Core/LLM/UnifiedMcpClient.php(43): App\\\\Core\\\\LLM\\\\LLMProviderFactory::fromEnv()\\n#1 /home/oliverbob/ginto/src/Routes/web.php(817): App\\\\Core\\\\LLM\\\\UnifiedMcpClient->__construct()\\n#2 [internal function]: {closure}()\\n#3 /home/oliverbob/ginto/src/Core/Router.php(150): call_user_func_array()\\n#4 /home/oliverbob/ginto/public/index.php(1139): Core\\\\Router->dispatch()\\n#5 {main}\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:29:42'),(29,1,'llm_provider_error','llm',NULL,'{\"message\":\"Tool not found: chat_completion\",\"meta\":{\"type\":\"mcp_invoke\",\"tool\":\"chat_completion\",\"arguments\":[]}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:29:59'),(30,1,'llm_provider_error','llm',NULL,'{\"message\":\"App\\\\Handlers\\\\DevTools::think(): Argument #1 ($thought) must be of type string, null given\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::think\",\"tool\":\"think\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:38:02'),(31,1,'llm_provider_error','llm',NULL,'{\"message\":\"API error: The model `gpt-4o` does not exist or you do not have access to it.\",\"meta\":{\"user_message\":\"test\",\"provider\":\"groq\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 13:50:03'),(32,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 14:47:07'),(33,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 14:47:43'),(34,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 14:50:48'),(35,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 14:57:48'),(36,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:05:56'),(37,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:06:37'),(38,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:06:45'),(39,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:06:56'),(40,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:06:59'),(41,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:07:00'),(42,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:07:05'),(43,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:07:06'),(44,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:07:07'),(45,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:07:14'),(46,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:46:57'),(47,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:46:59'),(48,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:47:01'),(49,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:47:44'),(50,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:47:49'),(51,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:48:09'),(52,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:48:55'),(53,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:48:59'),(54,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:49:02'),(55,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:49:12'),(56,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:49:18'),(57,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:49:21'),(58,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:49:37'),(59,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:49:41'),(60,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:49:54'),(61,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:49:55'),(62,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:49:57'),(63,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:50:00'),(64,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:50:02'),(65,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:50:05'),(66,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:50:10'),(67,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:50:24'),(68,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:51:57'),(69,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:52:35'),(70,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:53:48'),(71,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:55:41'),(72,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:55:46'),(73,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:55:48'),(74,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:56:09'),(75,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:57:10'),(76,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:57:12'),(77,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:57:14'),(78,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:57:16'),(79,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:58:02'),(80,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:58:06'),(81,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:58:11'),(82,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:58:21'),(83,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:58:23'),(84,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:58:24'),(85,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:58:30'),(86,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:58:32'),(87,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:58:33'),(88,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:58:34'),(89,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:58:35'),(90,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:58:52'),(91,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:58:58'),(92,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:59:09'),(93,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:59:12'),(94,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 16:59:16'),(95,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 16:59:26'),(96,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 17:00:28'),(97,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 17:00:35'),(98,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 17:01:12'),(99,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 17:01:14'),(100,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 17:01:16'),(101,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 17:01:18'),(102,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 17:02:05'),(103,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 17:02:10'),(104,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 17:12:24'),(105,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 17:12:27'),(106,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 17:15:27'),(107,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 17:15:30'),(108,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 17:24:18'),(109,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 18:31:41'),(110,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 18:31:44'),(111,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 18:31:54'),(112,1,'llm_provider_error','llm',NULL,'{\"message\":\"App\\\\Handlers\\\\DevTools::verifyFileContent(): Argument #2 ($expectedSubstring) must be of type string, null given\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::verifyFileContent\",\"tool\":\"verify_file_content\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 18:32:40'),(113,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 18:37:11'),(114,1,'llm_provider_error','llm',NULL,'{\"message\":\"API error: \'messages.7\' : for \'role:tool\' the following must be satisfied[(\'messages.7.tool_call_id\' : property \'tool_call_id\' is missing)]\",\"meta\":{\"user_message\":\"Thank you.\",\"provider\":\"groq\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 18:38:25'),(115,1,'llm_provider_error','llm',NULL,'{\"message\":\"Text not found exactly, but first line exists. Check whitespace/indentation.\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::replaceInFile\",\"tool\":\"replace_in_file\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 18:42:19'),(116,1,'llm_provider_error','llm',NULL,'{\"message\":\"App\\\\Handlers\\\\DevTools::searchFiles(): Argument #1 ($pattern) must be of type string, null given\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::searchFiles\",\"tool\":\"search_files\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 18:42:26'),(117,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 18:48:33'),(118,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 19:05:06'),(119,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 19:06:04'),(120,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 19:07:18'),(121,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 19:09:43'),(122,1,'llm_provider_error','llm',NULL,'{\"message\":\"File not found: shopee.html\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::readFile\",\"tool\":\"read_file\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 19:10:33'),(123,1,'llm_provider_error','llm',NULL,'{\"message\":\"File not found\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\CursorContext::getFile\",\"tool\":\"repo/get_file\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 19:13:32'),(124,1,'llm_provider_error','llm',NULL,'{\"message\":\"Text found 4 times. Add more context to uniquely identify the location.\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::replaceInFile\",\"tool\":\"replace_in_file\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 19:17:22'),(125,1,'llm_provider_error','llm',NULL,'{\"message\":\"App\\\\Handlers\\\\DevTools::searchFiles(): Argument #1 ($pattern) must be of type string, null given\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::searchFiles\",\"tool\":\"search_files\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-06 19:17:24'),(126,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 21:20:21'),(127,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 21:20:24'),(128,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 21:20:25'),(129,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-06 21:20:27'),(130,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-06 21:20:30'),(131,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:52:09'),(132,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:52:33'),(133,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:52:45'),(134,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:52:57'),(135,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:53:10'),(136,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:53:22'),(137,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:53:34'),(138,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:53:47'),(139,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:53:59'),(140,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:53:59'),(141,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:53:59'),(142,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:53:59'),(143,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:53:59'),(144,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:53:59'),(145,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:53:59'),(146,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:53:59'),(147,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:53:59'),(148,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:54:00'),(149,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:54:19'),(150,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:54:31'),(151,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 11:59:19'),(152,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 11:59:35'),(153,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:00:10'),(154,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:00:27'),(155,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:00:39'),(156,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:00:40'),(157,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:00:56'),(158,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:01:02'),(159,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:01:19'),(160,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:01:57'),(161,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:03:08'),(162,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:04:21'),(163,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:04:36'),(164,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:05:50'),(165,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:05:54'),(166,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:05:56'),(167,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:05:58'),(168,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:07:03'),(169,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:07:07'),(170,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:07:14'),(171,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:07:16'),(172,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:07:18'),(173,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:07:20'),(174,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-07 12:07:23'),(175,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-07 12:07:25'),(176,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-08 04:42:45'),(177,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-08 04:42:50'),(178,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-08 05:20:07'),(179,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-08 05:20:10'),(180,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-08 05:20:13'),(181,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-08 05:20:16'),(182,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-08 05:20:20'),(183,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-08 05:30:27'),(184,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-08 05:30:38'),(185,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-08 05:30:44'),(186,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-08 05:30:45'),(187,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-08 05:30:48'),(188,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-08 05:30:50'),(189,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-08 05:31:01'),(190,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-08 05:31:02'),(191,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":true}',NULL,NULL,'2025-12-08 05:31:24'),(192,1,'playground.toggle_admin_sandbox','playground.editor',NULL,'{\"use_sandbox\":false}',NULL,NULL,'2025-12-08 05:34:41'),(193,2,'llm_provider_error','llm',NULL,'{\"message\":\"File not found\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\CursorContext::getFile\",\"tool\":\"repo/get_file\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-09 04:39:55'),(194,2,'llm_provider_error','llm',NULL,'{\"message\":\"Text not found exactly, but first line exists. Check whitespace/indentation.\",\"meta\":{\"type\":\"handler_invocation\",\"handler\":\"\\\\App\\\\Handlers\\\\DevTools::replaceInFile\",\"tool\":\"replace_in_file\"}}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-09 04:54:15');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `parent_id` int DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `meta_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_sandboxes`
--

DROP TABLE IF EXISTS `client_sandboxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_sandboxes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned DEFAULT NULL,
  `public_id` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sandbox_id` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quota_bytes` bigint NOT NULL DEFAULT '104857600',
  `used_bytes` bigint NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sandbox_id` (`sandbox_id`),
  KEY `user_id` (`user_id`),
  KEY `idx_client_sandbox_id` (`sandbox_id`),
  CONSTRAINT `client_sandboxes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_sandboxes`
--

LOCK TABLES `client_sandboxes` WRITE;
/*!40000 ALTER TABLE `client_sandboxes` DISABLE KEYS */;
INSERT INTO `client_sandboxes` VALUES (1,2,NULL,'2nKOuHHSYDuL',104857600,64089,'2025-12-06 10:58:39','2025-12-09 04:56:08'),(2,1,NULL,'uQ65wRsPDhFH',104857600,16187,'2025-12-06 11:03:46','2025-12-07 12:08:33'),(3,NULL,NULL,'sWFHdj1CsJ5B',104857600,0,'2025-12-06 18:25:23','2025-12-07 02:25:23'),(4,NULL,NULL,'AaJHi0QNdTV5',104857600,0,'2025-12-06 19:02:07','2025-12-07 03:02:07');
/*!40000 ALTER TABLE `client_sandboxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','pending') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `metadata` json DEFAULT NULL COMMENT 'Additional client data as JSON',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_clients_email` (`email`),
  KEY `idx_clients_status` (`status`),
  KEY `idx_clients_company` (`company`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'John Doe','john@example.com','+1-555-0101','Acme Corp',NULL,NULL,NULL,'active','VIP customer',NULL,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(2,'Jane Smith','jane@example.com','+1-555-0102','Tech Solutions',NULL,NULL,NULL,'active',NULL,NULL,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(3,'Bob Wilson','bob@example.com','+1-555-0103','Startup Inc',NULL,NULL,NULL,'pending','Awaiting onboarding',NULL,'2025-12-06 13:24:49','2025-12-06 13:24:49');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `post_id` int NOT NULL,
  `parent_id` int DEFAULT NULL,
  `author_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `user_id` (`user_id`),
  KEY `idx_comments_post` (`post_id`),
  KEY `idx_comments_status` (`status`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_rates`
--

DROP TABLE IF EXISTS `commission_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_rates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `level` int unsigned NOT NULL,
  `rate` decimal(6,4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_rates`
--

LOCK TABLES `commission_rates` WRITE;
/*!40000 ALTER TABLE `commission_rates` DISABLE KEYS */;
INSERT INTO `commission_rates` VALUES (1,1,0.0500,'2025-12-06 13:24:48'),(2,2,0.0400,'2025-12-06 13:24:48'),(3,3,0.0300,'2025-12-06 13:24:48'),(4,4,0.0200,'2025-12-06 13:24:48'),(5,5,0.0100,'2025-12-06 13:24:48'),(6,6,0.0050,'2025-12-06 13:24:48'),(7,7,0.0025,'2025-12-06 13:24:48'),(8,8,0.0025,'2025-12-06 13:24:48'),(9,9,0.0000,'2025-12-06 13:24:48');
/*!40000 ALTER TABLE `commission_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commissions`
--

DROP TABLE IF EXISTS `commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `referrer_id` int unsigned DEFAULT NULL,
  `amount` decimal(18,8) NOT NULL,
  `type` enum('direct','indirect','bonus','override') COLLATE utf8mb4_unicode_ci DEFAULT 'direct',
  `level` tinyint NOT NULL DEFAULT '1',
  `transaction_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','paid','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_commissions_user` (`user_id`),
  KEY `idx_commissions_referrer` (`referrer_id`),
  KEY `idx_commissions_status` (`status`),
  CONSTRAINT `commissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commissions_ibfk_2` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commissions`
--

LOCK TABLES `commissions` WRITE;
/*!40000 ALTER TABLE `commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `levels`
--

DROP TABLE IF EXISTS `levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `levels` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost_amount` decimal(10,4) NOT NULL,
  `cost_currency` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `commission_rate_json` json NOT NULL COMMENT 'e.g., {"L1": 0.50, "L2": 0.10}',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `levels`
--

LOCK TABLES `levels` WRITE;
/*!40000 ALTER TABLE `levels` DISABLE KEYS */;
INSERT INTO `levels` VALUES (1,'Starter',150.0000,'PHP','{\"L1\": 0.01}','2025-12-06 13:24:49'),(2,'Basic',1000.0000,'PHP','{\"L1\": 0.02}','2025-12-06 13:24:49'),(3,'Silver',5000.0000,'PHP','{\"L1\": 0.05, \"L2\": 0.02}','2025-12-06 13:24:49'),(4,'Gold',10000.0000,'PHP','{\"L1\": 0.07, \"L2\": 0.03, \"L3\": 0.02}','2025-12-06 13:24:49'),(5,'Platinum',50000.0000,'PHP','{\"L1\": 0.1, \"L2\": 0.05, \"L3\": 0.03, \"L4\": 0.02, \"L5\": 0.01}','2025-12-06 13:24:49');
/*!40000 ALTER TABLE `levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` int DEFAULT NULL,
  `width` int DEFAULT NULL,
  `height` int DEFAULT NULL,
  `alt_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caption` text COLLATE utf8mb4_unicode_ci,
  `uploaded_by` int unsigned NOT NULL,
  `folder` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '/',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_media_uploaded_by` (`uploaded_by`),
  CONSTRAINT `media_ibfk_1` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `menu_id` int NOT NULL,
  `parent_id` int DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '_self',
  `css_class` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `page_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  KEY `parent_id` (`parent_id`),
  KEY `page_id` (`page_id`),
  CONSTRAINT `menu_items_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menu_items_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `menu_items` (`id`) ON DELETE SET NULL,
  CONSTRAINT `menu_items_ibfk_3` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `package` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Gold',
  `amount` decimal(18,8) NOT NULL DEFAULT '0.00000000',
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PHP',
  `status` enum('pending','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'completed',
  `metadata` json DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,4,'5',10000.00000000,'PHP','completed',NULL,'2025-12-09 05:44:07');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `template` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `author_id` int unsigned NOT NULL,
  `parent_id` int DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci,
  `custom_css` text COLLATE utf8mb4_unicode_ci,
  `custom_js` text COLLATE utf8mb4_unicode_ci,
  `published_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `parent_id` (`parent_id`),
  KEY `idx_pages_slug` (`slug`),
  KEY `idx_pages_status` (`status`),
  KEY `idx_pages_author` (`author_id`),
  CONSTRAINT `pages_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pages_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `pages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payouts`
--

DROP TABLE IF EXISTS `payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payouts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `amount` decimal(18,8) NOT NULL,
  `wallet_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','processing','completed','failed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `admin_notes` text COLLATE utf8mb4_unicode_ci,
  `requested_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `processed_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_payouts_user` (`user_id`),
  KEY `idx_payouts_status` (`status`),
  CONSTRAINT `payouts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payouts`
--

LOCK TABLES `payouts` WRITE;
/*!40000 ALTER TABLE `payouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT '0',
  `settings` text COLLATE utf8mb4_unicode_ci,
  `dependencies` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_tags`
--

DROP TABLE IF EXISTS `post_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_tags` (
  `post_id` int NOT NULL,
  `tag_id` int NOT NULL,
  PRIMARY KEY (`post_id`,`tag_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `post_tags_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_tags`
--

LOCK TABLES `post_tags` WRITE;
/*!40000 ALTER TABLE `post_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `author_id` int unsigned NOT NULL,
  `category_id` int DEFAULT NULL,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views` int DEFAULT '0',
  `meta_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci,
  `published_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_posts_slug` (`slug`),
  KEY `idx_posts_status` (`status`),
  KEY `idx_posts_author` (`author_id`),
  KEY `idx_posts_category` (`category_id`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` int unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `price_currency` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PHP',
  `category` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock` int DEFAULT '0',
  `image_path` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `badge` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT '0.00',
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `owner_id` (`owner_id`),
  KEY `category` (`category`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referrals`
--

DROP TABLE IF EXISTS `referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referrals` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `referrer_id` int unsigned NOT NULL COMMENT 'The user who referred (sponsor)',
  `referred_id` int unsigned NOT NULL COMMENT 'The user who was referred',
  `level_joined` int unsigned NOT NULL COMMENT 'Level at which the user joined',
  `status` enum('pending','active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `earnings_generated` decimal(18,8) NOT NULL DEFAULT '0.00000000' COMMENT 'Total commissions generated from this referral',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activated_at` datetime DEFAULT NULL COMMENT 'When the referral became active (paid)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_referred` (`referred_id`),
  KEY `level_joined` (`level_joined`),
  KEY `idx_referrer` (`referrer_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `referrals_ibfk_1` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `referrals_ibfk_2` FOREIGN KEY (`referred_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `referrals_ibfk_3` FOREIGN KEY (`level_joined`) REFERENCES `levels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referrals`
--

LOCK TABLES `referrals` WRITE;
/*!40000 ALTER TABLE `referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` int NOT NULL,
  `user_id` int unsigned NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `changes` text COLLATE utf8mb4_unicode_ci,
  `version` int DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `revisions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `is_system` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'super_admin','Super Administrator','Full system access','[\"*\"]',1,'2025-12-06 13:24:48','2025-12-06 13:24:48'),(2,'admin','Administrator','Site administration access','[\"admin.*\", \"content.*\", \"users.*\", \"themes.*\", \"plugins.*\"]',1,'2025-12-06 13:24:48','2025-12-06 13:24:48'),(3,'editor','Editor','Content management access','[\"content.*\", \"media.*\"]',1,'2025-12-06 13:24:48','2025-12-06 13:24:48'),(4,'author','Author','Content creation access','[\"content.create\", \"content.edit.own\", \"media.upload\"]',1,'2025-12-06 13:24:48','2025-12-06 13:24:48'),(5,'user','User','Basic user access','[\"dashboard.view\", \"profile.edit\"]',1,'2025-12-06 13:24:48','2025-12-06 13:24:48');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'string',
  `group_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'general',
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_public` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'site_name','Ginto CMS','string','general','Website name',1,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(2,'site_description','A modern content management system','string','general','Website description',1,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(3,'site_url','http://localhost:8000','string','general','Website URL',1,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(4,'admin_email','admin@example.com','string','general','Administrator email',0,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(5,'timezone','UTC','string','general','Default timezone',1,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(6,'date_format','Y-m-d','string','general','Date display format',1,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(7,'time_format','H:i:s','string','general','Time display format',1,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(8,'posts_per_page','10','integer','content','Posts per page',1,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(9,'comments_enabled','1','boolean','content','Enable comments',1,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(10,'registration_enabled','1','boolean','users','Allow user registration',1,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(11,'email_verification','0','boolean','users','Require email verification',0,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(12,'maintenance_mode','0','boolean','system','Maintenance mode enabled',0,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(13,'cache_enabled','1','boolean','system','Enable caching',0,'2025-12-06 13:24:49','2025-12-06 13:24:49'),(14,'debug_mode','0','boolean','system','Debug mode enabled',0,'2025-12-06 13:24:49','2025-12-06 13:24:49');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `themes`
--

DROP TABLE IF EXISTS `themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `themes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `screenshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT '0',
  `settings` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `themes`
--

LOCK TABLES `themes` WRITE;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL COMMENT 'The user affected (payer or recipient)',
  `type` enum('upgrade','commission','withdrawal','deposit','purchase','refund','bonus') COLLATE utf8mb4_unicode_ci NOT NULL,
  `level_id` int unsigned DEFAULT NULL COMMENT 'MLM level reference',
  `source_user_id` int unsigned DEFAULT NULL COMMENT 'The user who triggered the transaction (e.g., downline)',
  `amount` decimal(18,8) NOT NULL,
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'USD',
  `balance_before` decimal(18,8) DEFAULT '0.00000000',
  `balance_after` decimal(18,8) DEFAULT '0.00000000',
  `status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'completed',
  `tx_hash` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Blockchain hash for on-chain audit',
  `reference_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'External reference ID',
  `reference_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Type of reference (commission, payout, etc)',
  `description` text COLLATE utf8mb4_unicode_ci,
  `metadata` json DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tx_hash` (`tx_hash`),
  KEY `idx_transactions_user` (`user_id`),
  KEY `idx_transactions_type` (`type`),
  KEY `idx_transactions_level` (`level_id`),
  KEY `idx_transactions_source` (`source_user_id`),
  KEY `idx_transactions_reference` (`reference_type`,`reference_id`),
  KEY `idx_transactions_status` (`status`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`level_id`) REFERENCES `levels` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transactions_ibfk_3` FOREIGN KEY (`source_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `public_id` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referrer_id` int unsigned DEFAULT NULL,
  `fullname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middlename` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ginto_level` int unsigned NOT NULL DEFAULT '0',
  `wallet_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'User wallet for crypto payouts',
  `current_level_id` int unsigned NOT NULL DEFAULT '1',
  `total_balance` decimal(18,8) NOT NULL DEFAULT '0.00000000',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` int DEFAULT '5',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `last_login` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `two_factor_enabled` tinyint(1) DEFAULT '0',
  `preferences` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `playground_use_sandbox` tinyint(1) DEFAULT '0',
  `package` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `package_amount` decimal(18,8) DEFAULT NULL,
  `package_currency` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `public_id` (`public_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `wallet_address` (`wallet_address`),
  KEY `referrer_id` (`referrer_id`),
  KEY `current_level_id` (`current_level_id`),
  KEY `idx_users_role` (`role_id`),
  KEY `idx_users_status` (`status`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `users_ibfk_3` FOREIGN KEY (`current_level_id`) REFERENCES `levels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'e2fce0b4d26311f0',NULL,'Oliver Bob Reyes Lagumen',NULL,NULL,NULL,'admin','oliverbob.lagumen@gmail.com',NULL,NULL,'$2y$10$ctqrwRKWc/o0u4Um7viEh.mGur3YrSk9ib1wa.h.ryNKPZyTGWzV6',0,NULL,1,0.00000000,0,2,'active',NULL,NULL,NULL,NULL,0,NULL,'2025-12-06 13:24:50','2025-12-08 13:34:41',0,NULL,NULL,NULL,NULL),(2,'e308a52ad26311f0',NULL,'Default User - oliverbob',NULL,NULL,NULL,'oliverbob','aihcorp@gmail.com',NULL,NULL,'$2y$10$YmlLlMU1R3ulGh7oQmv6zeV4oF0fisWnXAprgprTbZaCg6FzjXNSW',0,NULL,1,0.00000000,0,5,'active',NULL,NULL,NULL,NULL,0,NULL,'2025-12-06 13:24:50','2025-12-06 13:24:50',0,NULL,NULL,NULL,NULL),(3,'7b311e5bd29111f0',NULL,'Test Admin',NULL,NULL,NULL,'test_admin_user','test_admin@example.local',NULL,NULL,'$2y$10$2aNR9orvYno3pLMgSyxVbeeeDwXiYCwqF79z/jclo.SuSQcX6/jyS',0,NULL,1,0.00000000,0,1,'active',NULL,NULL,NULL,NULL,0,NULL,'2025-12-06 10:51:12','2025-12-06 18:51:12',0,NULL,NULL,NULL,NULL),(4,'897f906d5c61afb5',2,'Eleanor Bajit Rojoas','Eleanor','Bajit','Rojoas','eleanor','eleanorrojas40@gmail.com','PH','09568706407','$2y$10$S9/lszZM2J/mWBleeHIMquOpAqtD8e8NsIx28hR9w/Dp/APzgkCsq',0,NULL,1,0.00000000,0,5,'active',NULL,NULL,NULL,NULL,0,NULL,'2025-12-09 05:44:07','2025-12-09 13:44:07',0,'5',NULL,'PHP',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`oliverbob`@`localhost`*/ /*!50003 TRIGGER `users_before_insert_public_id` BEFORE INSERT ON `users` FOR EACH ROW BEGIN
    IF NEW.public_id IS NULL OR NEW.public_id = '' THEN
        SET NEW.public_id = LEFT(REPLACE(UUID(), '-', ''), 16);
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` int DEFAULT '0',
  `settings` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-09 13:44:49
